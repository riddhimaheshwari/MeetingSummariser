# Meeting Summariser — Frontend

A React (Vite) frontend for the FastAPI backend in `backend/main.py`. Talks to
the exact endpoints that already exist there — no backend changes needed to
run this, beyond the diarization update from earlier.

## What it does

- Upload an audio file → shows upload progress → backend transcribes,
  diarizes, summarises, and embeds it (this can take a minute or two,
  depending on file length and your machine).
- Browse past meetings in the left rail.
- Per meeting: read the GPT-generated summary/agenda/decisions/action items,
  read the speaker-attributed transcript, read the raw transcript, ask
  questions (RAG chat), and download the generated PDF.

## Setup

```bash
cd frontend
npm install
npm run dev
```

This starts the dev server on **http://localhost:3000** — that exact port
(and 3001–3004) is already whitelisted in `backend/main.py`'s CORS config,
so don't change it unless you also update `origins` there.

## Running the backend alongside it

In a separate terminal, from your `backend/` folder:

```bash
uvicorn main:app --reload --port 8000
```

The frontend expects the API at `http://localhost:8000` — that's hardcoded
in `src/api.js` as `BASE_URL`. Change it there if you deploy the backend
somewhere else.

## Notes on how this maps to the backend

| UI feature | Backend endpoint |
|---|---|
| Upload audio | `POST /meetings/` (multipart, field `audio_file`) |
| Meeting list (sidebar) | `GET /meetings/` |
| Selecting a meeting | `GET /meetings/{meeting_id}` |
| Ask tab | `POST /meetings/{meeting_id}/chat` |
| Export tab | `GET /meetings/{meeting_id}/pdf` |

The upload call can take a while to return, because `main.py` processes
everything (transcription, diarization, summarization, embedding) inline
and synchronously before responding — there's no polling or background job
here, the frontend just waits on that one request. If you want a snappier
UX later, the natural next step is making `/meetings/` return immediately
with a "processing" status and polling `GET /meetings/{id}` until it's
ready, rather than blocking the whole request on the pipeline.
