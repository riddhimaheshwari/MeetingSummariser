import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// The backend (main.py) whitelists these exact ports in its CORS config,
// so we pin the dev server to 3000. If you need a different port, add it
// to the `origins` list in backend/main.py too.
export default defineConfig({
  plugins: [react()],
  server: {
    port: 3000,
  },
})
