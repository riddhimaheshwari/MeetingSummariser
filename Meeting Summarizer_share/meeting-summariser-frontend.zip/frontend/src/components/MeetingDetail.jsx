import { useState } from "react";
import SummaryTab from "./SummaryTab";
import SpeakerTranscriptTab from "./SpeakerTranscriptTab";
import ChatTab from "./ChatTab";
import { pdfDownloadUrl } from "../api";

const TABS = ["Summary", "Speaker Transcript", "Raw Transcript", "Ask", "Export"];

export default function MeetingDetail({ meeting, onChatTurn }) {
  const [activeTab, setActiveTab] = useState("Summary");

  return (
    <div className="content">
      <div className="letterhead">
        <h1 className="letterhead-title">{meeting.meeting_name || "Untitled meeting"}</h1>
        <p className="letterhead-meta">{meeting.upload_date} · {meeting.meeting_id}</p>
        <div className="tabs">
          {TABS.map((tab) => (
            <button
              key={tab}
              className={`tab-btn${activeTab === tab ? " active" : ""}`}
              onClick={() => setActiveTab(tab)}
            >
              {tab}
            </button>
          ))}
        </div>
      </div>

      <div className="tab-panel">
        {activeTab === "Summary" && <SummaryTab summary={meeting.summary} />}

        {activeTab === "Speaker Transcript" && (
          <SpeakerTranscriptTab speakerTranscript={meeting.speaker_transcript} />
        )}

        {activeTab === "Raw Transcript" && (
          <pre className="raw-transcript">{meeting.raw_transcript}</pre>
        )}

        {activeTab === "Ask" && (
          <ChatTab
            meetingId={meeting.meeting_id}
            chatHistory={meeting.chat_history || []}
            onNewTurn={(turn) => onChatTurn(meeting.meeting_id, turn)}
          />
        )}

        {activeTab === "Export" && (
          <div>
            <p style={{ marginBottom: 16, color: "var(--text-muted)" }}>
              Download the generated minutes of meeting as a PDF.
            </p>
            <a
              className="btn-secondary"
              href={pdfDownloadUrl(meeting.meeting_id)}
              target="_blank"
              rel="noreferrer"
            >
              Download PDF
            </a>
          </div>
        )}
      </div>
    </div>
  );
}
