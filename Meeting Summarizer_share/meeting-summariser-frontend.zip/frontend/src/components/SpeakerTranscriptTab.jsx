// Parses lines of the form "Speaker 1: some text" (or "Unknown Speaker: text")
// produced by backend/utils/diarization.py, and renders each with a
// tape-counter style index plus a colour-coded speaker tag.
function parseLines(speakerTranscript) {
  if (!speakerTranscript) return [];
  return speakerTranscript
    .split("\n")
    .filter((line) => line.trim().length > 0)
    .map((line) => {
      const match = line.match(/^(.+?):\s*(.*)$/);
      if (!match) return { speaker: "Unknown Speaker", text: line };
      return { speaker: match[1].trim(), text: match[2].trim() };
    });
}

function speakerClass(speaker) {
  const num = parseInt(speaker.replace(/\D/g, ""), 10);
  if (Number.isNaN(num)) return "s0";
  return `s${num % 4}`;
}

export default function SpeakerTranscriptTab({ speakerTranscript }) {
  const lines = parseLines(speakerTranscript);

  if (lines.length === 0) {
    return <p className="chat-empty">No speaker-attributed transcript available.</p>;
  }

  return (
    <div>
      {lines.map((line, i) => (
        <div className="transcript-line" key={i}>
          <span className="transcript-counter">{String(i + 1).padStart(3, "0")}</span>
          <span className={`transcript-speaker ${speakerClass(line.speaker)}`}>
            {line.speaker}
          </span>
          <span>{line.text}</span>
        </div>
      ))}
    </div>
  );
}
