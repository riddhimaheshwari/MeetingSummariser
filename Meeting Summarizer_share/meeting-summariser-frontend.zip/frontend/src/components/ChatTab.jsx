import { useState } from "react";
import { askQuestion } from "../api";

export default function ChatTab({ meetingId, chatHistory, onNewTurn }) {
  const [question, setQuestion] = useState("");
  const [asking, setAsking] = useState(false);
  const [error, setError] = useState(null);

  async function handleAsk(e) {
    e.preventDefault();
    const trimmed = question.trim();
    if (!trimmed || asking) return;

    setAsking(true);
    setError(null);
    try {
      const result = await askQuestion(meetingId, trimmed);
      onNewTurn({ question: result.question, answer: result.answer });
      setQuestion("");
    } catch (err) {
      setError(err.message || "Something went wrong asking that question.");
    } finally {
      setAsking(false);
    }
  }

  return (
    <div>
      {error && <div className="error-banner">{error}</div>}

      <div className="chat-log">
        {chatHistory.length === 0 ? (
          <p className="chat-empty">
            Ask anything about this meeting - e.g. "What did we decide about the
            launch date?" Answers are grounded in the actual transcript via
            retrieval, not the model guessing.
          </p>
        ) : (
          chatHistory.map((turn, i) => (
            <div className="chat-turn" key={i}>
              <div className="chat-bubble question">{turn.question}</div>
              <div className="chat-bubble answer">{turn.answer}</div>
            </div>
          ))
        )}
        {asking && <p className="thinking">searching transcript...</p>}
      </div>

      <form className="chat-input-row" onSubmit={handleAsk}>
        <input
          type="text"
          placeholder="Ask a question about this meeting"
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
          disabled={asking}
        />
        <button className="btn-primary" type="submit" disabled={asking || !question.trim()}>
          Ask
        </button>
      </form>
    </div>
  );
}
