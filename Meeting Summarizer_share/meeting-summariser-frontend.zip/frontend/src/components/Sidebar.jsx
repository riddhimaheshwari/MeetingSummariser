import { useRef, useState } from "react";
import { uploadMeeting } from "../api";

function formatDate(isoLikeString) {
  if (!isoLikeString) return "";
  const d = new Date(isoLikeString);
  if (Number.isNaN(d.getTime())) return isoLikeString;
  return d.toLocaleString(undefined, {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export default function Sidebar({ meetings, activeId, onSelect, onUploaded }) {
  const fileInputRef = useRef(null);
  const [dragging, setDragging] = useState(false);
  const [status, setStatus] = useState(null); // { text, error, progress }

  async function handleFile(file) {
    if (!file) return;
    setStatus({ text: "Uploading...", progress: 0, error: false });
    try {
      const result = await uploadMeeting(file, (progress) => {
        setStatus({ text: `Uploading... ${progress}%`, progress, error: false });
      });
      setStatus({ text: "Transcribing & summarising - this can take a minute", error: false });
      // Backend processes synchronously and only responds once done,
      // so by the time we get here the meeting is fully ready.
      onUploaded(result.meeting_id);
      setStatus(null);
    } catch (err) {
      setStatus({ text: err.message || "Upload failed.", error: true });
    }
  }

  function onDrop(e) {
    e.preventDefault();
    setDragging(false);
    const file = e.dataTransfer.files?.[0];
    handleFile(file);
  }

  return (
    <aside className="sidebar">
      <p className="sidebar-brand">Meeting Summariser</p>
      <p className="sidebar-tagline">TRANSCRIBE // SUMMARISE // ASK</p>

      <div
        className={`upload-zone${dragging ? " dragging" : ""}`}
        onDragOver={(e) => {
          e.preventDefault();
          setDragging(true);
        }}
        onDragLeave={() => setDragging(false)}
        onDrop={onDrop}
      >
        <label className="upload-label">
          <span className={`rec-dot${status ? " pulsing" : ""}`} />
          Upload meeting audio
          <input
            ref={fileInputRef}
            type="file"
            accept="audio/*"
            style={{ display: "none" }}
            onChange={(e) => handleFile(e.target.files?.[0])}
          />
        </label>
        <p className="upload-hint">Drop an MP3/WAV here, or click to browse.</p>
        {status && (
          <p className={`upload-status${status.error ? " error" : ""}`}>{status.text}</p>
        )}
      </div>

      <p className="sidebar-section-label">Past meetings</p>
      {meetings.length === 0 ? (
        <p className="sidebar-empty">
          No meetings yet. Upload a recording above to get a transcript, summary,
          and Q&amp;A for it.
        </p>
      ) : (
        <ul className="reel-list">
          {meetings.map((m) => (
            <li key={m.meeting_id}>
              <button
                className={`reel-item${m.meeting_id === activeId ? " active" : ""}`}
                onClick={() => onSelect(m.meeting_id)}
              >
                <span className="reel-icon" />
                <span className="reel-meta">
                  <span className="reel-name">{m.meeting_name || "Untitled meeting"}</span>
                  <br />
                  <span className="reel-date">{formatDate(m.upload_date)}</span>
                </span>
              </button>
            </li>
          ))}
        </ul>
      )}
    </aside>
  );
}
