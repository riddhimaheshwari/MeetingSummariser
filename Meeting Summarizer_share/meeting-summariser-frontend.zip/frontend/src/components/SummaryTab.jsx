export default function SummaryTab({ summary }) {
  if (!summary) {
    return <p className="chat-empty">No summary was generated for this meeting.</p>;
  }

  return (
    <div>
      <div className="summary-block">
        <h3>Summary</h3>
        <p>{summary.concise_summary}</p>
      </div>

      {summary.agenda_items?.length > 0 && (
        <div className="summary-block">
          <h3>Agenda items</h3>
          <ul>
            {summary.agenda_items.map((item, i) => (
              <li key={i}>{item}</li>
            ))}
          </ul>
        </div>
      )}

      {summary.decisions_made?.length > 0 && (
        <div className="summary-block">
          <h3>Decisions made</h3>
          <ul>
            {summary.decisions_made.map((item, i) => (
              <li key={i}>{item}</li>
            ))}
          </ul>
        </div>
      )}

      {summary.action_items?.length > 0 && (
        <div className="summary-block">
          <h3>Action items</h3>
          {summary.action_items.map((item, i) => (
            <div className="action-item" key={i}>
              <span className="who">{item.responsible_person}</span>
              <span>{item.task_date}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
