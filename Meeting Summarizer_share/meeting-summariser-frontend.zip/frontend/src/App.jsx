import { useEffect, useState, useCallback } from "react";
import Sidebar from "./components/Sidebar";
import MeetingDetail from "./components/MeetingDetail";
import { listMeetings, getMeeting } from "./api";

export default function App() {
  const [meetings, setMeetings] = useState([]);
  const [activeId, setActiveId] = useState(null);
  const [activeMeeting, setActiveMeeting] = useState(null);
  const [loadError, setLoadError] = useState(null);

  const refreshList = useCallback(async () => {
    try {
      const data = await listMeetings();
      setMeetings(data);
      setLoadError(null);
    } catch (err) {
      setLoadError(
        "Couldn't reach the backend at localhost:8000. Is `uvicorn main:app --reload` running?"
      );
    }
  }, []);

  useEffect(() => {
    refreshList();
  }, [refreshList]);

  useEffect(() => {
    if (!activeId) {
      setActiveMeeting(null);
      return;
    }
    getMeeting(activeId).then(setActiveMeeting).catch(() => setActiveMeeting(null));
  }, [activeId]);

  async function handleUploaded(meetingId) {
    await refreshList();
    setActiveId(meetingId);
  }

  // Optimistically append the new chat turn locally, rather than
  // re-fetching the whole meeting after every single question.
  function handleChatTurn(meetingId, turn) {
    setActiveMeeting((prev) =>
      prev && prev.meeting_id === meetingId
        ? { ...prev, chat_history: [...(prev.chat_history || []), turn] }
        : prev
    );
  }

  return (
    <div className="app-shell">
      <Sidebar
        meetings={meetings}
        activeId={activeId}
        onSelect={setActiveId}
        onUploaded={handleUploaded}
      />

      {loadError ? (
        <div className="empty-state">
          <div className="empty-state-inner">
            <h2>Backend not reachable</h2>
            <p>{loadError}</p>
          </div>
        </div>
      ) : activeMeeting ? (
        <MeetingDetail meeting={activeMeeting} onChatTurn={handleChatTurn} />
      ) : (
        <div className="empty-state">
          <div className="empty-state-inner">
            <h2>Select or upload a meeting</h2>
            <p>
              Choose a past meeting from the left, or upload a new recording to
              get a transcript, summary, and Q&amp;A for it.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
