// Thin wrapper around the FastAPI backend in backend/main.py.
// Every function here maps 1:1 to one endpoint - no guessing at shapes,
// this matches the Pydantic models in main.py exactly.

const BASE_URL = "http://localhost:8000";

async function handle(res) {
  if (!res.ok) {
    let detail = res.statusText;
    try {
      const body = await res.json();
      detail = body.detail || detail;
    } catch {
      // response wasn't JSON, fall back to statusText
    }
    throw new Error(detail);
  }
  return res.json();
}

// POST /meetings/  (multipart form, field name: audio_file)
// -> { message, meeting_id, meeting_name }
export async function uploadMeeting(file, onProgress) {
  const formData = new FormData();
  formData.append("audio_file", file);

  // Using XHR instead of fetch here specifically to get upload progress -
  // fetch has no built-in progress event for request bodies.
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open("POST", `${BASE_URL}/meetings/`);
    xhr.upload.onprogress = (e) => {
      if (onProgress && e.lengthComputable) {
        onProgress(Math.round((e.loaded / e.total) * 100));
      }
    };
    xhr.onload = () => {
      if (xhr.status >= 200 && xhr.status < 300) {
        resolve(JSON.parse(xhr.responseText));
      } else {
        let detail = xhr.statusText;
        try {
          detail = JSON.parse(xhr.responseText).detail || detail;
        } catch {
          // ignore parse failure, use statusText
        }
        reject(new Error(detail));
      }
    };
    xhr.onerror = () => reject(new Error("Network error while uploading audio."));
    xhr.send(formData);
  });
}

// GET /meetings/  -> MeetingBase[]
export async function listMeetings() {
  const res = await fetch(`${BASE_URL}/meetings/`);
  return handle(res);
}

// GET /meetings/{id}  -> MeetingBase
export async function getMeeting(meetingId) {
  const res = await fetch(`${BASE_URL}/meetings/${meetingId}`);
  return handle(res);
}

// POST /meetings/{id}/chat  { question } -> { question, answer }
export async function askQuestion(meetingId, question) {
  const res = await fetch(`${BASE_URL}/meetings/${meetingId}/chat`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ question }),
  });
  return handle(res);
}

// GET /meetings/{id}/pdf  -> triggers a browser download
export function pdfDownloadUrl(meetingId) {
  return `${BASE_URL}/meetings/${meetingId}/pdf`;
}
